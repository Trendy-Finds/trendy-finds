# Trendy Finds — ready-to-publish static store

This folder contains a polished responsive storefront using the 4 supplied products and optimized product images.

## Products
- Vintage T9 Dragon Professional Hair Trimmer — Rs. 1,300
- Cordless High-Pressure Washer Gun — Rs. 4,500
- 8.5-inch LCD Writing Tablet — Rs. 1,000
- Wireless Bluetooth Headphones — Rs. 1,500

## Order flow
The View & Order button opens a product detail modal. Customers enter name, phone and city, then the order opens in WhatsApp to **0343-2453563** with Cash on Delivery selected.

## GitHub Pages
Replace the files in the repository root with the contents of this folder, commit, then keep GitHub Pages set to `main` / `(root)`.

## Important
Real customer reviews were NOT fabricated. The site uses trust/benefit blocks instead. Add genuine customer feedback once you have it.
Product videos can be added later when you provide the video files or public video links.
